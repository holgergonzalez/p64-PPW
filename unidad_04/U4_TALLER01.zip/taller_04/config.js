const config = {
    PORT: 3000,
    //DB_URL: 'mongodb://dba:dba@localhost:27020/miapp?authSource=admin'
    //DB_URL: 'mongodb://localhost:27017/''mongodb://localhost:27017/miapp?authSource=admin'
    DB_URL: 'mongodb+srv://gonzalezh2002:<gonzalezh2002>@cluster0.kying.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
}

module.exports = config